
import java.awt.event.*;
import java.awt.*;
import javax.swing.*;
import java.util.Random;

public class Jogo {

    String[] perguntas = {
        "De quem é a famosa frase “Penso, logo existo”?",
        "De onde é a invenção do chuveiro elétrico?",
        "Quais o <b>menor</b> e o <b>maior</b> país do mundo?",
        "Qual o nome do <b>presidente do Brasil</b> que ficou conhecido como Jango?",
        "Qual o grupo em que <b>todas as palavras</b> foram escritas corretamente?",
        "Qual o livro <b>mais vendido no mundo</b> a seguir à Bíblia?",
        "Quantas casas <b>decimais</b> tem o número pi?",
        "Atualmente, quantos <b>elementos químicos</b> a tabela periódica possui?",
        "Quais os países que têm a <b>maior</b> e a <b>menor</b> expectativa de vida do mundo?",
        "O que a palavra <b>legend</b> significa em português?",
        "Qual o <b>número mínimo de jogadores</b> em cada time numa partida de futebol?",
        "Quais os principais autores do <b>Barroco</b> no Brasil?",
        "Quais as <b>duas datas</b> que são comemoradas em novembro?",
        "Quanto tempo a <b>luz do Sol</b> demora para chegar à Terra?",
    };

    String[] alternativaA = {
        "Platão",
        "França",
        "Vaticano e Rússia",
        "Jânio Quadros",
        "Asterístico, beneficiente, meteorologia, entertido",
        "O Senhor dos Anéis",
        "Duas",
        "113",
        "Japão e Serra Leoa",
        "Legenda",
        "8",
        "Gregório de Matos, Bento Teixeira e Manuel Botelho de Oliveira",
        "Independência do Brasil e Dia da Bandeira",
        "12 minutos"
    };

    String[] alternativaB = {
        "Galileu Galilei",
        "Inglaterra",
        "Nauru e China",
        "Jacinto Anjos",
        "Asterisco, beneficente, meteorologia, entretido",
        "Dom Quixote",
        "Centenas",
        "109",
        "Austrália e Afeganistão",
        "Conto",
        "10",
        "Miguel de Cervantes, Gregório de Matos e Danthe Alighieri",
        "Proclamação da República e Dia Nacional da Consciência Negra",
        "1 dia"
    };

    String[] alternativaC = {
        "Descartes",
        "Brasil",
        "Mônaco e Canadá",
        "Getúlio Vargas",
        "Asterisco, beneficente, metereologia, entretido",
        "O Pequeno Príncipe",
        "Infinitas",
        "108",
        "Itália e Chade",
        "Lenda",
        "7",
        "Padre Antônio Vieira, Padre Manuel de Melo e Gregório de Matos",
        "Dia do Médico e Dia de São Lucas",
        "12 horas"
    };

    String[] alternativaD = {
        "Sócrates",
        "Austrália",
        "Malta e Estados Unidos",
        "João Goulart",
        "Asterístico, beneficiente, metereologia, entretido",
        "Ela, a Feiticeira",
        "Vinte",
        "118",
        "Brasil e Congo",
        "Legendário",
        "9",
        "Castro Alves, Bento Teixeira e Manuel Botelho de Oliveira",
        "Dia de Finados e Dia Nacional do Livro",
        "8 minutos"
    };

    String[] resposta = {
        "Descartes",
        "Brasil",
        "Vaticano e Rússia",
        "João Goulart",
        "Asterisco, beneficente, meteorologia, entretido",
        "Dom Quixote",
        "Infinitas",
        "118",
        "Japão e Serra Leoa",
        "Lenda",
        "7",
        "Gregório de Matos, Bento Teixeira e Manuel Botelho de Oliveira",
        "Proclamação da República e Dia Nacional da Consciência Negra",
        "8 minutos"
    };

    String opA;
    String opB;
    String opC;
    String opD;
    String pergunta;
    String tempo;

    static int l = 15;

    int[] jaForam = new int[perguntas.length];
    int jaFoi = 0;
    int corretas = 0;
    int total = jaForam.length;
    int sec = 10;
    int resultado;
    int numeroSorteado;

    Random sorteio = new Random();

    JFrame frame;
    JPanel painel;
    JLabel indexAtual = new JLabel();
    JLabel titulo = new JLabel("", SwingConstants.CENTER);
    JLabel timer = new JLabel("", SwingConstants.CENTER);
    JButton opcA = new JButton();
    JButton opcB = new JButton();
    JButton opcC = new JButton();
    JButton opcD = new JButton();
    Timer cron;
    ActionListener Aaction;

    public Jogo(){
       telaJogo();
    }

    public void verificaQuestao(){

        if(total != 1){
            numeroSorteado = sorteio.nextInt(perguntas.length);

            if(jaForam[numeroSorteado] != numeroSorteado){
                jaForam[numeroSorteado] = numeroSorteado;
                total = total - 1;
            } else {
                verificaQuestao();
            }
        } else {
            JOptionPane.showMessageDialog(frame, "Fim! Você acertou " + corretas + " de " + resposta.length + " .");
            System.exit(0);
        }

    }

    public void telaJogo(){

        verificaQuestao();

        painel = new JPanel((new BorderLayout(0, 0)));
        frame = new JFrame();

        frame.setTitle("Quiz");
        frame.setSize(620, 690);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setResizable(false);
        frame.setLocationRelativeTo(null);
        frame.setLayout(null);

        pergunta = ("<html><body><p style='padding: 40px; text-align: justify; background-color: #ffd000;'>" + perguntas[numeroSorteado] + "</p></body></html>");
        titulo.setText(pergunta);
        titulo.setBounds(18, 20, 565, 176);
        titulo.setFont(new Font("Arial", 0, 28));
        titulo.setForeground(Color.decode("#606060"));
        frame.add(titulo);

        opA = ("<html><body><p style='padding: 20px; text-align: justify;'>A. " + alternativaA[numeroSorteado] + "</p></body></html>");
        opcA.setText(opA);
        opcA.setBounds(18, 200, 280, 170);
        opcA.setFont(new Font("Arial", 0, 18));
        opcA.setBorder(null);
        opcA.setBackground(Color.decode("#005dc7"));
        opcA.setForeground(Color.decode("#FFFFFF"));
        opcA.setFocusable(false);
        frame.add(opcA);
        
        opcA.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent e) {
                for(int i = 0; i <= numeroSorteado; i++){
                    if(alternativaD[numeroSorteado].equals(resposta[i])){
                        opcA.setBackground(Color.decode("#ff4747"));
                        opcA.setForeground(Color.decode("#FFFFFF"));
                        opcB.setBackground(Color.decode("#ff4747"));
                        opcB.setForeground(Color.decode("#FFFFFF"));
                        opcC.setBackground(Color.decode("#ff4747"));
                        opcC.setForeground(Color.decode("#FFFFFF"));
                        opcD.setBackground(Color.decode("#3bff44"));
                        opcD.setForeground(Color.decode("#FFFFFF"));
                        gerar();
                    } else if(alternativaA[numeroSorteado].equals(resposta[i])) {
                        corretas = corretas + 1;
                        cron.stop(); 
                        l = 15;
                        opcA.setBackground(Color.decode("#3bff44"));
                        opcA.setForeground(Color.decode("#FFFFFF"));
                        opcB.setBackground(Color.decode("#ff4747"));
                        opcB.setForeground(Color.decode("#FFFFFF"));
                        opcC.setBackground(Color.decode("#ff4747"));
                        opcC.setForeground(Color.decode("#FFFFFF"));
                        opcD.setBackground(Color.decode("#ff4747"));
                        opcD.setForeground(Color.decode("#FFFFFF"));
                        gerar();
                    } else if(alternativaB[numeroSorteado].equals(resposta[i])) {
                        opcA.setBackground(Color.decode("#ff4747"));
                        opcA.setForeground(Color.decode("#FFFFFF"));
                        opcB.setBackground(Color.decode("#3bff44"));
                        opcB.setForeground(Color.decode("#FFFFFF"));
                        opcC.setBackground(Color.decode("#ff4747"));
                        opcC.setForeground(Color.decode("#FFFFFF"));
                        opcD.setBackground(Color.decode("#ff4747"));
                        opcD.setForeground(Color.decode("#FFFFFF"));
                        gerar();
                    } else if(alternativaC[numeroSorteado].equals(resposta[i])) {
                        opcA.setBackground(Color.decode("#ff4747"));
                        opcA.setForeground(Color.decode("#FFFFFF"));
                        opcB.setBackground(Color.decode("#ff4747"));
                        opcB.setForeground(Color.decode("#FFFFFF"));
                        opcC.setBackground(Color.decode("#3bff44"));
                        opcC.setForeground(Color.decode("#FFFFFF"));
                        opcD.setBackground(Color.decode("#ff4747"));
                        opcD.setForeground(Color.decode("#FFFFFF"));
                        gerar();
                    }
                }
            }
            
        });
        
        opB = ("<html><body><p style='padding: 20px; text-align: justify;'>B. " + alternativaB[numeroSorteado] + "</p></body></html>");;
        opcB.setText(opB);
        opcB.setBounds(303, 200, 280, 170);
        opcB.setFont(new Font("Arial", 0, 18));
        opcB.setBorder(null);
        opcB.setBackground(Color.decode("#005dc7"));
        opcB.setForeground(Color.decode("#FFFFFF"));
        opcB.setFocusable(false);
        frame.add(opcB);

        opcB.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent e) {
                for(int i = 0; i <= numeroSorteado; i++){
                    if(alternativaD[numeroSorteado].equals(resposta[i])){
                        opcA.setBackground(Color.decode("#ff4747"));
                        opcA.setForeground(Color.decode("#FFFFFF"));
                        opcB.setBackground(Color.decode("#ff4747"));
                        opcB.setForeground(Color.decode("#FFFFFF"));
                        opcC.setBackground(Color.decode("#ff4747"));
                        opcC.setForeground(Color.decode("#FFFFFF"));
                        opcD.setBackground(Color.decode("#3bff44"));
                        opcD.setForeground(Color.decode("#FFFFFF"));
                        gerar();
                    } else if(alternativaA[numeroSorteado].equals(resposta[i])) {
                        opcA.setBackground(Color.decode("#3bff44"));
                        opcA.setForeground(Color.decode("#FFFFFF"));
                        opcB.setBackground(Color.decode("#ff4747"));
                        opcB.setForeground(Color.decode("#FFFFFF"));
                        opcC.setBackground(Color.decode("#ff4747"));
                        opcC.setForeground(Color.decode("#FFFFFF"));
                        opcD.setBackground(Color.decode("#ff4747"));
                        opcD.setForeground(Color.decode("#FFFFFF"));
                        gerar();
                    } else if(alternativaB[numeroSorteado].equals(resposta[i])) {
                        corretas = corretas + 1;
                        cron.stop(); 
                        l = 15;
                        opcA.setBackground(Color.decode("#ff4747"));
                        opcA.setForeground(Color.decode("#FFFFFF"));
                        opcB.setBackground(Color.decode("#3bff44"));
                        opcB.setForeground(Color.decode("#FFFFFF"));
                        opcC.setBackground(Color.decode("#ff4747"));
                        opcC.setForeground(Color.decode("#FFFFFF"));
                        opcD.setBackground(Color.decode("#ff4747"));
                        opcD.setForeground(Color.decode("#FFFFFF"));
                        gerar();
                    } else if(alternativaC[numeroSorteado].equals(resposta[i])) {
                        opcA.setBackground(Color.decode("#ff4747"));
                        opcA.setForeground(Color.decode("#FFFFFF"));
                        opcB.setBackground(Color.decode("#ff4747"));
                        opcB.setForeground(Color.decode("#FFFFFF"));
                        opcC.setBackground(Color.decode("#3bff44"));
                        opcC.setForeground(Color.decode("#FFFFFF"));
                        opcD.setBackground(Color.decode("#ff4747"));
                        opcD.setForeground(Color.decode("#FFFFFF"));
                        gerar();
                    }
                }
            }
            
        });

        opC = ("<html><body><p style='padding: 20px; text-align: justify;'>C. " + alternativaC[numeroSorteado] + "</p></body></html>");;
        opcC.setText(opC);
        opcC.setBounds(18, 375, 280, 170);
        opcC.setFont(new Font("Arial", 0, 18));
        opcC.setBorder(null);
        opcC.setBackground(Color.decode("#005dc7"));
        opcC.setForeground(Color.decode("#FFFFFF"));
        opcC.setFocusable(false);
        frame.add(opcC);

        opcC.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent e) {
                for(int i = 0; i <= numeroSorteado; i++){
                    if(alternativaD[numeroSorteado].equals(resposta[i])){
                        opcA.setBackground(Color.decode("#ff4747"));
                        opcA.setForeground(Color.decode("#FFFFFF"));
                        opcB.setBackground(Color.decode("#ff4747"));
                        opcB.setForeground(Color.decode("#FFFFFF"));
                        opcC.setBackground(Color.decode("#ff4747"));
                        opcC.setForeground(Color.decode("#FFFFFF"));
                        opcD.setBackground(Color.decode("#3bff44"));
                        opcD.setForeground(Color.decode("#FFFFFF"));
                        gerar();
                    } else if(alternativaA[numeroSorteado].equals(resposta[i])) {
                        opcA.setBackground(Color.decode("#3bff44"));
                        opcA.setForeground(Color.decode("#FFFFFF"));
                        opcB.setBackground(Color.decode("#ff4747"));
                        opcB.setForeground(Color.decode("#FFFFFF"));
                        opcC.setBackground(Color.decode("#ff4747"));
                        opcC.setForeground(Color.decode("#FFFFFF"));
                        opcD.setBackground(Color.decode("#ff4747"));
                        opcD.setForeground(Color.decode("#FFFFFF"));
                        gerar();
                    } else if(alternativaB[numeroSorteado].equals(resposta[i])) {
                        opcA.setBackground(Color.decode("#ff4747"));
                        opcA.setForeground(Color.decode("#FFFFFF"));
                        opcB.setBackground(Color.decode("#3bff44"));
                        opcB.setForeground(Color.decode("#FFFFFF"));
                        opcC.setBackground(Color.decode("#ff4747"));
                        opcC.setForeground(Color.decode("#FFFFFF"));
                        opcD.setBackground(Color.decode("#ff4747"));
                        opcD.setForeground(Color.decode("#FFFFFF"));
                        gerar();
                    } else if(alternativaC[numeroSorteado].equals(resposta[i])) {
                        corretas = corretas + 1;
                        cron.stop();  
                        l = 15;
                        opcA.setBackground(Color.decode("#ff4747"));
                        opcA.setForeground(Color.decode("#FFFFFF"));
                        opcB.setBackground(Color.decode("#ff4747"));
                        opcB.setForeground(Color.decode("#FFFFFF"));
                        opcC.setBackground(Color.decode("#3bff44"));
                        opcC.setForeground(Color.decode("#FFFFFF"));
                        opcD.setBackground(Color.decode("#ff4747"));
                        opcD.setForeground(Color.decode("#FFFFFF"));
                        gerar();
                    }
                }
            }
            
        });

        opD = ("<html><body><p style='padding: 20px; text-align: justify;'>D. " + alternativaD[numeroSorteado] + "</p></body></html>");;
        opcD.setText(opD);
        opcD.setBounds(303, 375, 280, 170);
        opcD.setFont(new Font("Arial", 0, 18));
        opcD.setBorder(null);
        opcD.setBackground(Color.decode("#005dc7"));
        opcD.setForeground(Color.decode("#FFFFFF"));
        opcD.setFocusable(false);
        frame.add(opcD);

        opcD.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent e) {
                for(int i = 0; i <= numeroSorteado; i++){
                    if(alternativaD[numeroSorteado].equals(resposta[i])){
                        corretas = corretas + 1;
                        cron.stop();
                        l = 15;
                        opcA.setBackground(Color.decode("#ff4747"));
                        opcA.setForeground(Color.decode("#FFFFFF"));
                        opcB.setBackground(Color.decode("#ff4747"));
                        opcB.setForeground(Color.decode("#FFFFFF"));
                        opcC.setBackground(Color.decode("#ff4747"));
                        opcC.setForeground(Color.decode("#FFFFFF"));
                        opcD.setBackground(Color.decode("#3bff44"));
                        opcD.setForeground(Color.decode("#FFFFFF"));
                        gerar();
                    } else if(alternativaA[numeroSorteado].equals(resposta[i])) {
                        opcA.setBackground(Color.decode("#3bff44"));
                        opcA.setForeground(Color.decode("#FFFFFF"));
                        opcB.setBackground(Color.decode("#ff4747"));
                        opcB.setForeground(Color.decode("#FFFFFF"));
                        opcC.setBackground(Color.decode("#ff4747"));
                        opcC.setForeground(Color.decode("#FFFFFF"));
                        opcD.setBackground(Color.decode("#ff4747"));
                        opcD.setForeground(Color.decode("#FFFFFF"));
                        gerar();
                    } else if(alternativaB[numeroSorteado].equals(resposta[i])) {
                        opcA.setBackground(Color.decode("#ff4747"));
                        opcA.setForeground(Color.decode("#FFFFFF"));
                        opcB.setBackground(Color.decode("#3bff44"));
                        opcB.setForeground(Color.decode("#FFFFFF"));
                        opcC.setBackground(Color.decode("#ff4747"));
                        opcC.setForeground(Color.decode("#FFFFFF"));
                        opcD.setBackground(Color.decode("#ff4747"));
                        opcD.setForeground(Color.decode("#FFFFFF"));
                        gerar();
                    } else if(alternativaC[numeroSorteado].equals(resposta[i])) {
                        opcA.setBackground(Color.decode("#ff4747"));
                        opcA.setForeground(Color.decode("#FFFFFF"));
                        opcB.setBackground(Color.decode("#ff4747"));
                        opcB.setForeground(Color.decode("#FFFFFF"));
                        opcC.setBackground(Color.decode("#3bff44"));
                        opcC.setForeground(Color.decode("#FFFFFF"));
                        opcD.setBackground(Color.decode("#ff4747"));
                        opcD.setForeground(Color.decode("#FFFFFF"));
                        gerar();
                    }
                }
            }
            
        });


        Aaction = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(l <= 15){
                    timer.setText(("<html><body><p style='padding: 195px; text-align: justify; background-color: #00a303;'>" + l + "</p></body></html>"));
                }
                if(l < 10){
                    timer.setText(("<html><body><p style='padding: 195px; text-align: justify; background-color: #00a303;'>0" + l + "</p></body></html>"));
                }
                if(l == 0){
                    JOptionPane.showMessageDialog(frame, "Tempo esgotado!");
                    cron.stop();
                    gerar();
                }
                l = l - 1;    
            }
        };
        cron = new Timer(1000, Aaction);
        cron.setInitialDelay(0);
        cron.setRepeats(true);
        cron.start(); 
        

        timer.setBounds(0, 550, 600, 80);
        timer.setFont(new Font("Arial", 0, 55));
        timer.setForeground(Color.decode("#FFFFFF"));
        frame.add(timer);

        frame.setVisible(true);
        frame.add(painel);
        
    }

    public void gerar(){

        ActionListener listener = new ActionListener(){
            public void actionPerformed(ActionEvent event){
                        
                verificaQuestao();

                opcA.setBackground(Color.decode("#005dc7"));
                opcB.setBackground(Color.decode("#005dc7"));
                opcC.setBackground(Color.decode("#005dc7"));
                opcD.setBackground(Color.decode("#005dc7"));

                pergunta = ("<html><body><p style='padding: 40px; text-align: justify; background-color: #ffd000;'>" + perguntas[numeroSorteado] + "</p></body></html>");
                titulo.setText(pergunta);
                opA = ("<html><body><p style='padding: 20px; text-align: justify;'>A. " + alternativaA[numeroSorteado] + "</p></body></html>");
                opcA.setText(opA);
                opB = ("<html><body><p style='padding: 20px; text-align: justify;'>B. " + alternativaB[numeroSorteado] + "</p></body></html>");;
                opcB.setText(opB);
                opC = ("<html><body><p style='padding: 20px; text-align: justify;'>C. " + alternativaC[numeroSorteado] + "</p></body></html>");;
                opcC.setText(opC);
                opD = ("<html><body><p style='padding: 20px; text-align: justify;'>D. " + alternativaD[numeroSorteado] + "</p></body></html>");;
                opcD.setText(opD);
                tempo = ("<html><body><p style='padding: 195px; text-align: justify; background-color: #00a303;'>" + 15 + "</p></body></html>");
                timer.setText(tempo);
                l = 15;
                cron.start(); 

            }
        };
        Timer timer = new Timer(1000, listener);
        timer.setRepeats(false);
        timer.start();

    }

}

